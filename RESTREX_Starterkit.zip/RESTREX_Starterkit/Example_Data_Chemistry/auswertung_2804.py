# -*- coding: utf-8 -*-
"""
Created on Fri Dec 17 13:59:53 2021

@author: Achim Retzbach

@version: 1.1.0
"""


import numpy as np
import matplotlib.pyplot as plt
from os import listdir
from tabulate import tabulate
import scipy.odr as odr


def std(arr):
    '''
    Returns the empiric variance of an input array as float.
    Note the difference to numpy.std, which gives the population variance!!!

    Parameters
    ----------
    arr : int/float-array
        The array to calculate the empiric variance of.

    Returns
    -------
    s : float
        The input array's empiric variance.'

    '''
    s=0
    for k in range(0,len(arr)):
        s=s+(arr[k]-np.mean(arr))**2
        if k==len(arr)-1:
            s=np.sqrt(s/(len(arr)-1))
    return s


def linear(B,x):
    '''Linear function.'''
    return B[0]*x+B[1]


def proportional(B,x):
    '''Proportional function.'''
    return B[0]*x

def stringToFloat(s):
    '''
    #TODO

    Parameters
    ----------
    s : TYPE
        DESCRIPTION.

    Returns
    -------
    None.

    '''
    try:
        out=float(s)
    except:
        out=0
    return out


def getData(filepath,outputs,transpose_input=True):
    '''
    Function to get specified arrays from a previously generated raw-text csv-file.
    (Just open the Qtegra-.xml in OpenOffice and export as .csv with tabulator separator again.)

    Parameters
    ----------
    filepath : string
        Path of the input csv file
    outputs : string-array
        Abbreviations of the isotopes to export. Possible options: '44Ca', '83Kr', '85Rb', '88Sr'
    transpose_input : boolean, optional
        If the input of a category is given in rows, set this to False.
        If its in columns (as usual), set this to true. The default is True.

    Returns
    -------
    output : array of string/float-arrays
        Array which contains all data specified in outputs, ordered from lowest to highest mass.
        The last array is always the label of the data (e.g. BLK, STD, A1, ...)
    '''
    #Read-in of data (needs to be converted to simple csv list before!)
    daten = np.loadtxt(filepath,dtype='str',skiprows=2,delimiter='\u0009')
    if transpose_input==True:
        daten=np.matrix.transpose(daten)
    index=daten[0]
    category=daten[1]
    alllabels=daten[2] #shortened version below!
    runs=daten[3]
    sampletype=daten[4]
    dilutionfactor=daten[5]
    comment=daten[6]
    ca44=daten[7]
    kr83=daten[8]
    rb85=daten[9]
    sr88=daten[10]
    
    #Sorting data into array for concentration/intensity, according to elements
    #WARNING: Concentrations for other isotopes than 88Sr are string values!!!
    label=[]
    ca44conc=[]
    d_ca44conc=[]
    ca44int=[]
    d_ca44int=[]
    kr83conc=[]
    d_kr83conc=[]
    kr83int=[]
    d_kr83int=[]
    rb85conc=[]
    d_rb85conc=[]
    rb85int=[]
    d_rb85int=[]
    sr88conc=[]
    d_sr88conc=[]
    sr88int=[]
    d_sr88int=[]
    for i in range(0,int(len(index)/4)):
        label.append(alllabels[4*i])
        ca44int.append(stringToFloat(ca44[4*i]))
        d_ca44int.append(stringToFloat(ca44[4*i+1]))
        ca44conc.append(ca44[4*i+2])
        d_ca44conc.append(ca44[4*i+3])
        kr83int.append(stringToFloat(kr83[4*i]))
        d_kr83int.append(stringToFloat(kr83[4*i+1]))
        kr83conc.append(kr83[4*i+2])
        d_kr83conc.append(kr83[4*i+3])
        rb85int.append(stringToFloat(rb85[4*i]))
        d_rb85int.append(stringToFloat(rb85[4*i+1]))
        rb85conc.append(rb85[4*i+2])
        d_rb85conc.append(rb85[4*i+3])
        sr88int.append(stringToFloat(sr88[4*i]))
        d_sr88int.append(stringToFloat(sr88[4*i+1]))
        sr88conc.append(stringToFloat(sr88[4*i+2]))
        d_sr88conc.append(stringToFloat(sr88[4*i+3]))
    
    #Generate output
    output=[]
    if ('44ca' in outputs) or ('44Ca' in outputs) or ('Ca44' in outputs) or ('ca44' in outputs):
        output.append(ca44int)
        output.append(d_ca44int)
        output.append(ca44conc)
        output.append(d_ca44conc)
    if ('83kr' in outputs) or ('83Kr' in outputs) or ('Kr83' in outputs) or ('kr83' in outputs):
        output.append(kr83int)
        output.append(d_kr83int)
        output.append(kr83conc)
        output.append(d_kr83conc)
    if ('85rb' in outputs) or ('85Rb' in outputs) or ('Rb85' in outputs) or ('rb85' in outputs):
        output.append(rb85int)
        output.append(d_rb85int)
        output.append(rb85conc)
        output.append(d_rb85conc)
    if ('88sr' in outputs) or ('88Sr' in outputs) or ('Sr88' in outputs) or ('sr88' in outputs):
        output.append(sr88int)
        output.append(d_sr88int)
        output.append(sr88conc)
        output.append(d_sr88conc)
    output.append(label)
    return output


def correctDilution(uncorrected_data,dilution_factors):
    '''
    Function to correct an array of floats with a custom dilution factor each.

    Parameters
    ----------
    uncorrected_data : float-array
        Input array of float values to correct.
    dilution_factors : float/int-array
        Dilution factors array, one factor for EACH element of uncorrected_data!

    Returns
    -------
    corrected_data : float-array
        Array of input data multiplied with the given dilution factors.
    '''
    corrected_data=[]
    for i in range(0,len(uncorrected_data)):
        corrected_data.append(uncorrected_data[i]*dilution_factors[i])
    return corrected_data
        
        
def sliceArray(array,slices):
    '''
    Simple function to slice an array according to a list of slice indices.

    Parameters
    ----------
    array : array of arbitrary type
        The array to slice.
    slices : array of two-element integer-arrays (i.e. tuples) / integers
        Single integers in this array will be interpreted as indices at which
        data from array are sliced out. Tuples will be interpreted as intervals
        of indices between which data from array are sliced out. Note that the
        former index within such a tuple is the first to be used while the
        latter is the first index to not be used anymore.

    Returns
    -------
    output : array of arbitrary type
        Sliced version of input, according to the parameters specified.
    '''
    output=[]
    for i in range(0,len(slices)):
        if type(slices[i])==int:
            output.append(array[slices[i]])
        elif len(slices[i])==2:
            for element in array[slices[i][0]:slices[i][1]]:
                output.append(element)
    return output


def calibrateData(data,blank_slices,calibration_conc,d_calibration_conc=[],calibration_slices=[],plots=[]):
    '''
    Function to perform a blank correction and upfollowing a custom ODR
    concentration calibration on a raw dataset given in counts.

    Parameters
    ----------
    data : array of at least two float-arrays
        Input of the raw data in counts. The first element is expected to be
        the counts themselves, the second array to be their errors. All further
        elements of data are ignored. Supposed to work with the getData()
        output.
    blank_slices : array of ints or int-tuples
        Determines where the blanks are within data. Has to have the format
        used in sliceArray(). 
        If the input is [], a different fit routine is used: Instead of fitting
        a proportional function to calibration vs. concentration, a linear 
        function (with y intercept) is used. The blank correction is then
        determined from the intercept and subtracted after the fit.
    calibration_conc : float/int-array
        The concentrations corresponding to the known-concentration
        measurements specified in calibration_slices.
    d_calibration_conc : float/int-array, optional
        The concentrations corresponding to the known-concentration
        measurements specified in calibration_slices. If none are given, zero
        values are generated. Note that this could lead to a significantly
        lower fit quality because of ODR issues! The default is [].
    calibration_slices : array of ints or int-tuples, optional
        Determines where the known-concentration measurements are within data.
        Has to have the format used in sliceArray() and specify as many
        elements as there are values within calibration_conc.
        The default is [].
    plots : string or string-array, optional
        Whether to display (and save) plots to better assess the quality of the
        fit. Possible options for plots here are:
            'calib'
            'calib_counts'
        The default is [].

    Returns
    -------
    sr88counts : float-array
        Blank-corrected counts.
    d_sr88counts : float-array
        Error of the blank-corrected counts.
    concs_corr : TYPE
        Newly calibrated concentrations.
    d_concs_corr : TYPE
        Error of newly calibrated concentrations.

    '''
    #Read-in
    sr88counts=data[0]
    d_sr88counts=data[1]
    
    #Calibration error fillup (if not given)
    if d_calibration_conc==[]:
        for i in range(0,len(calibration_conc)):
            d_calibration_conc.append(0)
    
    #Blank correction
    if blank_slices!=[]:
        blank_counts=sliceArray(sr88counts,blank_slices)
        d_blank_counts=sliceArray(d_sr88counts,blank_slices)
        mean_blank=np.mean(blank_counts)
        quadsum=0
        for d in d_blank_counts:
            quadsum=quadsum+d**2
        d_mean_blank=np.sqrt(quadsum)/len(blank_slices)
        sr88counts_blank=[]
        d_sr88counts_blank=[]
        for i in range(0,len(sr88counts)):
            sr88counts_blank.append(np.abs(sr88counts[i]-mean_blank))
            d_sr88counts_blank.append(np.sqrt(d_sr88counts[i]**2+d_mean_blank**2))
        calibrationcounts=sliceArray(sr88counts_blank,calibration_slices)
        d_calibrationcounts=sliceArray(d_sr88counts_blank,calibration_slices)
    elif blank_slices==[]:
        calibrationcounts=sliceArray(sr88counts,calibration_slices)
        d_calibrationcounts=sliceArray(d_sr88counts,calibration_slices)
        sr88counts_blank=sr88counts
        d_sr88counts_blank=d_sr88counts
    if len(calibrationcounts) != len(calibration_conc):
        print('ERROR: Length of calibration counts and calibration concentration doesnt match!')
        print('-- Most probably you have specified wrong calibration_slices or Frgt/10 elements in calbration_counts!')
    
    #Concentration calibration
    if blank_slices!=[]:
        fitmodel=odr.Model(proportional)
        beta=[1e-6]
    if blank_slices==[]:
        fitmodel=odr.Model(linear)
        beta=[1e-6,0]
    print(d_calibrationcounts)
    print()
    print(d_calibration_conc)
    fitdata=odr.RealData(calibrationcounts,calibration_conc,sx=d_calibrationcounts,sy=d_calibration_conc)
    fitodr=odr.ODR(fitdata,fitmodel,beta0=beta)
    fitoutput=fitodr.run()
    print('======= Fit Output =======')
    fitoutput.pprint()
    print('=====================')
        
    #Recalibrate to zero-concentration counts (if activated)
    if blank_slices==[]:
        zero_counts=-fitoutput.beta[1]/fitoutput.beta[0]
        d_zero_counts=zero_counts*np.sqrt((fitoutput.sd_beta[0]/fitoutput.beta[0])**2+(fitoutput.sd_beta[1]/fitoutput.beta[1])**2)
        sr88counts_zero=[]
        d_sr88counts_zero=[]
        for i in range(0,len(sr88counts_blank)):
            sr88counts_zero.append(np.abs(sr88counts_blank[i]-zero_counts))
            d_sr88counts_zero.append(np.sqrt(d_sr88counts_blank[i]**2+d_zero_counts**2))
            
    #Get new concentrations:
    concs_corr=[]
    d_concs_corr=[]
    if blank_slices!=[]:
        for i in range(0,len(sr88counts_blank)):
            newconc=proportional(fitoutput.beta,sr88counts_blank[i])
            concs_corr.append(newconc)
            d_concs_corr.append(np.sqrt((d_sr88counts_blank[i]*fitoutput.beta[0])**2+(sr88counts_blank[i]*fitoutput.sd_beta[0])**2))
    if blank_slices==[]:
        for i in range(0,len(sr88counts_zero)):
            newconc=linear(fitoutput.beta,sr88counts_zero[i])
            concs_corr.append(newconc)
            d_concs_corr.append(np.sqrt((d_sr88counts_zero[i]*fitoutput.beta[0])**2+(fitoutput.sd_beta[0]*sr88counts_zero[i])**2))
            
    #Plot calibration
    if 'calib' in plots:
        plt.figure()
        plt.errorbar(calibrationcounts,calibration_conc,d_calibration_conc,d_calibrationcounts,label='Data (baseline-corrected)')
        plt.errorbar(sliceArray(sr88counts,calibration_slices),calibration_conc,d_calibration_conc,sliceArray(d_sr88counts,calibration_slices),label='Data (raw)',linestyle=':')
        x=np.linspace(0,calibrationcounts[len(calibrationcounts)-1]*1.1,100)
        if blank_slices!=[]:
            plt.plot(x,proportional(fitoutput.beta,x),label='Fit')
        if blank_slices==[]:
            print('HIIIIIIIIII ',fitoutput.beta)
            plt.plot(x,linear(fitoutput.beta,x),label='Fit')
        plt.title('Calibration curve')
        plt.xlabel('Counts')
        plt.ylabel('Concentration [ppm]')
        plt.axhline(y=0, color='grey', linestyle=':')
        plt.legend()
        plt.savefig('Desktop/Auswertung/column_auswertung_output/calibration.png',dpi=200)
        
    #Plot counts
    if 'calib_counts' in plots:
        plt.figure()
        if blank_slices!=[]:
           plt.plot(sr88counts,sr88counts_blank,marker='.',linestyle='none')
        elif blank_slices==[]:
            plt.plot(sr88counts,sr88counts_zero,marker='.',linestyle='none')
        plt.plot(np.linspace(0,max(sr88counts)*1.1,2),np.linspace(0,max(sr88counts)*1.1,2),color='grey',label='1:1 line')
        plt.title('Own vs. Qtegra counts')
        plt.xlabel('QTegra Counts')
        plt.ylabel('Own Counts')
        plt.legend()
        plt.grid()
        
    #Output
    if blank_slices!=[]:
        return sr88counts_blank,d_sr88counts_blank,concs_corr,d_concs_corr
    if blank_slices==[]:
        return sr88counts_zero,d_sr88counts_zero,concs_corr,d_concs_corr
    
    
def correctDrift(data,drift_indices,plots):
    '''
    Function to perform a drift correction on a given dataset. The correction
    is made by renormalizing all specified drift measurements to the count
    level of the first one and then linearily interpolating the renormalization
    factors in between drift measurements in order to correct them.

    Parameters
    ----------
    data : array of four float-arrays
        Dataset to perform the correction on. The first element needs to be the
        array of counts, the second its error, the third one the array of
        concentrations and the fourth one in turn its error.
    drift_indices : int-array
        Indices of the drift measurements within the dataset. Here no slice
        notation, just simple integers accepted!
    plots : string or string-array
        Specifies if any additional plots are shown. Possible options (that
        trigger a plot if found within this input) are:
            'drift'

    Returns
    -------
    driftcounts : float-array
        Count array after the drift correction.
    d_driftcounts : float-array
        Error of count array after the drift correction.
    driftconcs : float-array
        Concentration array after the drift correction.
    d_driftconcs : float-array
        Error of concentration array after the drift correction.

    '''
    drift_indices=np.sort(drift_indices)
    previousfactor=1
    previouserror=0
    driftcounts=[]
    d_driftcounts=[]
    driftconcs=[]
    d_driftconcs=[]
    for k in range(0,drift_indices[0]):
        driftcounts.append(data[0][k])
        d_driftcounts.append(data[1][k])
        driftconcs.append(data[2][k])
        d_driftconcs.append(data[3][k])
    for i in range(0,len(drift_indices)):
        currentfactor=data[0][drift_indices[i]]/data[0][drift_indices[0]]
        currenterror=currentfactor*np.sqrt((data[1][drift_indices[i]]/data[0][drift_indices[i]])**2+(data[1][drift_indices[0]]/data[0][drift_indices[0]])**2)
        for j in range(drift_indices[i-1],drift_indices[i]):
            interpolatedfactor=((currentfactor*(j-drift_indices[i-1])/(drift_indices[i]-drift_indices[i-1])+previousfactor*(drift_indices[i]-j)/(drift_indices[i]-drift_indices[i-1])))
            d_interpolatedfactor=np.sqrt((currenterror*(j-drift_indices[i-1])/(drift_indices[i]-drift_indices[i-1]))**2+(previouserror*(drift_indices[i]-j)/(drift_indices[i]-drift_indices[i-1]))**2)
            driftcounts.append(data[0][j]/interpolatedfactor)
            d_driftcounts.append(np.sqrt((d_interpolatedfactor/interpolatedfactor)**2+(data[1][j]/data[0][j])**2)*data[0][j]/interpolatedfactor)

            driftconcs.append(data[2][j]/interpolatedfactor)
            d_driftconcs.append(np.sqrt((d_interpolatedfactor/interpolatedfactor)**2+(data[3][j]/data[2][j])**2)*data[2][j]/interpolatedfactor)
        previousfactor=currentfactor
        previouserror=currenterror
    lastdriftcount=data[0][j+1]/(data[0][drift_indices[len(drift_indices)-1]]/data[0][drift_indices[0]])
    driftcounts.append(lastdriftcount)
    d_driftcounts.append(lastdriftcount*np.sqrt((data[1][j+1]/data[0][j+1])**2+(data[1][drift_indices[len(drift_indices)-1]]/data[0][drift_indices[len(drift_indices)-1]])**2+(data[1][drift_indices[0]]/data[0][drift_indices[0]])**2))
    lastdriftconc=data[2][j+1]/(data[2][drift_indices[len(drift_indices)-1]]/data[2][drift_indices[0]])
    driftconcs.append(lastdriftconc)
    d_driftconcs.append(lastdriftconc*np.sqrt((data[3][j+1]/data[2][j+1])**2+(data[3][drift_indices[len(drift_indices)-1]]/data[2][drift_indices[len(drift_indices)-1]])**2+(data[3][drift_indices[0]]/data[2][drift_indices[0]])**2))        
    for k in range(drift_indices[len(drift_indices)-1]+1,len(data[0])):
        driftcounts.append(data[0][k])
        d_driftcounts.append(data[1][k])
        driftconcs.append(data[2][k])
        d_driftconcs.append(data[3][k])
    if 'drift' in plots:
        y1=[]
        for i in range(0,len(drift_indices)):
            y1.append(data[0][drift_indices[i]])
        plt.figure()
        plt.errorbar(range(0,len(driftcounts)),driftcounts,d_driftcounts,color='green',label='Drift-corrected Counts')
        plt.plot(range(0,len(data[0])),data[0],linestyle=':',color='blue',label='Uncorrected Counts')
        plt.plot(drift_indices,y1,linestyle='none',marker='o',color='red',label='Drifts')
        plt.axhline(data[0][drift_indices[0]], color='grey', linestyle='-',label='Normalized Drift Level')
        plt.title('Drift Correction')
        plt.xlabel('Index')
        plt.ylabel('Counts')
        plt.legend()
        plt.savefig('Desktop/Auswertung/column_auswertung_output/drift.png',dpi=200)
    return driftcounts,d_driftcounts,driftconcs,d_driftconcs
        
        
def examineSr(filepath,isotopes=['88sr'],recalibrate=True,blank_slices=[],calibration_conc=[],d_calibration_conc=[],calibration_slices=[], drift_correction=True, drift_indices=[], custom_xs=[], custom_slices=[], custom_labels=[],
              probe_slices=[],wash_slices_1=[],elution_slices_1=[],wash_slices_2=[],elution_slices_2=[],wash_index=-1,elution_index=-1, x_values=[], original_amount=-1, tube_size=1, dilution_factors=[],plots='none',table=True):  
    '''
    Main function to take the data given by getData and plot it/ tabulate it/ 
    calculate column efficiency.
    Uses calibrateData() and correctDrift() in order to perform a custom
    concentration calibration with blank correction and drift correction first.

    Parameters
    ----------
    filepath : string
        Path of input file, is given over to getData().
    isotopes: string/string-array
        Array of string literals identifying the isotope to inspect.
        Possible options are:
            '44ca'/'44Ca'/'Ca44'/'ca44'
            '83kr'/'83Kr'/'Kr83'/'kr83'
            '85rb'/'85Rb'/'Rb85'/'rb85'
            '88sr'/'88Sr'/'Sr88'/'sr88'
        The default is 'sr88'.
    recalibrate : boolean, optional
        Whether to perform a new calibration with blank correction (True) or
        not (False). The default is True.
    blank_slices : array of ints or int-tuples, optional
        Slices of indices corresponding to blank measurements, in the notation
        used in sliceArray(). Given over to calibrateData() and used for blank
        correction. The default is [].
    calibration_conc : float/int-array
        The concentrations corresponding to the known-concentration
        measurements specified in calibration_slices. The default is [].
    d_calibration_conc : float/int-array, optional
        The concentrations corresponding to the known-concentration
        measurements specified in calibration_slices. If none are given, zero
        values are generated. Note that this could lead to a significantly
        lower fit quality because of ODR issues! The default is [].
    calibration_slices : array of ints or int-tuples, optional
        Determines where the known-concentration measurements are within data.
        Has to have the format used in sliceArray() and specify as many
        elements as there are values within calibration_conc.
        The default is [].
    drift_correction : boolean, optional
        Whether to perform a drift correction (True) or not (False).
        The default is True.
    drift_indices : int-array, optional
        Indices of the drift measurements within the dataset. Here no slice
        notation, just simple integers accepted! The default is [].
    custom_xs : #TODO
    custom_slices : #TODO
    custom_labels : #TODO
    probe_slices : array of ints or int-tuples
        Slices of indices corresponding to probe measurements, in the notation
        used in sliceArray(). Used to cut out anything that is not a probe.
    wash_slices_1 : array of ints or int-tuples, optional
        Slices of indices corresponding to (the first) series of wash
        measurements, in the notation used in sliceArray(). IMPORTANT: Applies
        to array already sliced with probe_slices ! The default is [].
    elution_slices_1 : array of ints or int-tuples, optional
        Slices of indices corresponding to (the first) series of elution
        measurements, in the notation used in sliceArray(). IMPORTANT: Applies
        to array already sliced with probe_slices ! The default is [].
    wash_slices_2 : array of ints or int-tuples, optional
        Slices of indices corresponding to (a second) series of wash
        measurements, in the notation used in sliceArray(). IMPORTANT: Applies
        to array already sliced with probe_slices ! The default is [].
    elution_slices_2 : array of ints or int-tuples, optional
        Slices of indices corresponding to (a second) series of wash
        measurements, in the notation used in sliceArray(). IMPORTANT: Applies
        to array already sliced with probe_slices ! The default is [].
    wash_index : integer, optional
        Index of an additional single-measurement wash data point (e.g. total).
        Can be displayed as horizontal line/single data point, if not -1.
        IMPORTANT: Applies to array already sliced with probe_slices !
        The default is -1.
    elution_index : integer, optional
        Index of an additional single-measurement elution data point (e.g.
        total). Can be displayed as horizontal line/single data point, if not
        -1. IMPORTANT: Applies to array already sliced with probe_slices !
        The default is -1.
    x_values : float/int-array, optional
        array of float/int-arrays and optionally float/int
        The x-values over which to mae wash/elution plots. In an array, this is
        unpacked the following way:
            1. wash_indices_1
            2. elution_indices_1
            3. wash_indices_2
            4. elution_indices_2
            (all as arrays!)
            5. wash_index
            6. elution_index
            (as single float/int-numbers!)
        If this is [], only x-values for wash/elution_indices_1 are generated
        and they are subsequent numbers starting from 1. The default is [].
    original_amount : int/float, optional
        The original Sr amount before column chemistry. The unit depends on the
        units specified for tube_size and the concentration. In case they are
        ml/ppb, this is ml*ppb=pl. If this is -1, no efficiency calculation is
        performed. The default is -1.
    tube_size : int/float, optional
        Size of the probe tube put into the spectrometer, needed for efficiency
        calculation. Unit depends on the unit specified for original_amount and
        for the concentration. In case they are ml/ppb, this here is ml.
        The default is 1.
    dilution_factors : float/int-array, optional
        Array of dilution factors to give over to correctDilution() in case a
        dilution is needed. Leave empty if no dilution wished. In that case, do
        NOT specify steps in which dilution correction is needed later on.
        The default is [].
    plots : string or string-array, optional
        Specifies which step (string) or steps (string-array) to plot. Is also
        given over to  calibrateData() and correctDrift().
        Possible options are:
            'calib'
            'calib_counts'
            'drif'
            'wash_corr'
            'wash_uncorr'
            'wash_perc'
            'wash_cumul'
            'wash_counts'
            'elution_corr'
            'elution_uncorr'
            'elution_perc'
            'elution_cumul'
            'elution_counts'
        The option 'elution_cumul' includes an efficiency calculation!
        The default is 'none'.
    table : boolean, optional
        If true, prints a table with content corresponding to the other
        parameters.

    Returns
    -------
    None.

    '''
    
    alldata=[]
    currentraw=getData(filepath,outputs=isotopes,transpose_input=True)
    for isotope in isotopes:
        #Unpacking input/ recalibrating (if enabled)
        currentraw=getData(filepath,outputs=isotopes,transpose_input=True)
        if probe_slices==[]:
            probe_slices=[[0,len(currentraw[0])]]
        if recalibrate==True:
            allcounts,d_allcounts,allconcs,d_allconcs=calibrateData(data=currentraw,blank_slices=blank_slices,calibration_conc=calibration_conc,d_calibration_conc=d_calibration_conc,calibration_slices=calibration_slices,plots=plots)
            probecounts=sliceArray(allcounts,probe_slices)
            d_probecounts=sliceArray(d_allcounts,probe_slices)
            probeconc=sliceArray(allconcs,probe_slices)
            d_probeconc=sliceArray(d_allconcs,probe_slices)
        if recalibrate==False:
            allcounts=currentraw[0]
            d_allcounts=currentraw[1]
            allconcs=currentraw[2]
            d_allconcs=currentraw[3]
            probecounts=sliceArray(currentraw[0],probe_slices)
            d_probecounts=sliceArray(currentraw[1],probe_slices)
            for k in range(0,len(currentraw[2])):
                currentraw[2][k]=stringToFloat(currentraw[2][k])
                currentraw[3][k]=stringToFloat(currentraw[3][k])
            probeconc=sliceArray(currentraw[2],probe_slices)
            d_probeconc=sliceArray(currentraw[3],probe_slices)
        probelabels=sliceArray(currentraw[4],probe_slices)
        
        #Drift correction
        if drift_correction==True:
            driftcounts,d_driftcounts,driftconcs,d_driftconcs=correctDrift(data=[allcounts,d_allcounts,allconcs,d_allconcs],drift_indices=drift_indices,plots=plots)
            probecounts=sliceArray(driftcounts, probe_slices)
            d_probeconc=sliceArray(d_driftcounts, probe_slices)
            probeconc=sliceArray(driftconcs, probe_slices)
            d_probeconc=sliceArray(d_driftconcs, probe_slices)
            
        #Collecting data from multiple isotopes
        alldata.append([probecounts,d_probecounts,probeconc,d_probeconc])
                                           
        #Dilution correction
        if dilution_factors!=[]:
            sr88corr=correctDilution(probeconc, dilution_factors)
            d_sr88corr=correctDilution(d_probeconc, dilution_factors)    
                
        #Error messages
        '''
        #TODO
        if wash_slices_1==[]:
            print('WARNING: NO SLICES FOR WASH SPECIFIED!')
            #wash_slices_1=[0,len(currentraw[2])]
        if elution_slices_1==[]:
            print('WARNING: NO SLICES FOR ELUTION SPECIFIED!')
            #elution_slices_1=[0,len(currentraw[2])]
        if x_values==[]:
            print('WARNING: NO X-VALUES SPECIFIED!')
            #x_values=[np.arange(1,len(currentraw[2])),np.arange(1,len(currentraw[2]))]
        if ('wash_corr' in plots or 'elution_corr' in plots) and dilution_factors!=[]:
            print('WARNING: DILUTION-CORRECTED PLOTS REQUESTED, BUT NO DILUTION FACTORS GIVEN!')
        if drift_correction==True and drift_indices==[]:
            print('WARNING: DRIFT CORRECTION REQUESTED BUT NO DRIFT INDICES GIVEN!')
        '''
        
        #Printing table
        if table==True:
            if ('counts' in plots):
                table1=np.matrix.transpose(np.array([range(0,len(currentraw[4])),np.array(currentraw[4]),np.array(allcounts),np.array(currentraw[0])]))
                header1=['Index','Label','Own Counts','QTegra Counts']
                print(tabulate(table1,headers=header1))
            elif drift_correction==True:
                table1=np.matrix.transpose(np.array([range(0,len(currentraw[4])),np.array(currentraw[4]),np.array(allcounts),np.array(currentraw[0]),np.array(driftcounts)]))
                header1=['Index','Label','Own Counts','QTegra Counts','Drift-Corrected C.']
                print(tabulate(table1,headers=header1))
            elif recalibrate==True:
                table1=np.matrix.transpose(np.array([range(0,len(currentraw[4])),currentraw[4],allconcs,currentraw[2]]))
                header1=['Index','Label','Own Conc.','QTegra Conc.']
                print(tabulate(table1,headers=header1))
            elif dilution_factors!=[]:
                 table1=np.matrix.transpose(np.array([range(0,len(probelabels)),probelabels,probeconc,d_probeconc,sr88corr,d_sr88corr]))
                 header1=['Index','Label','Unc. Conc.','(error)','Corr. Conc.','(error)']
                 print(tabulate(table1,headers=header1))
            else:
                table1=np.matrix.transpose(np.array([range(0,len(probelabels)),probelabels,probeconc,d_probeconc]))
                header1=['Index','Label','Conc.','(error)']
                print(tabulate(table1,headers=header1))
            headers=''
            for s in header1:
                headers=headers+s+'\u0009'
            np.savetxt('Desktop/Auswertung/column_auswertung_output/current_table.csv',table1,delimiter='\u0009',fmt="%s",header=headers)
            
        #Plot dilution-corrected wash concentration
        if 'wash_corr' in plots and dilution_factors!=[]:
            y1=sliceArray(sr88corr,wash_slices_1)
            y2=sliceArray(sr88corr,wash_slices_2)
            d_y1=sliceArray(d_sr88corr,wash_slices_1)
            d_y2=sliceArray(d_sr88corr,wash_slices_2)
            plt.figure()
            plt.errorbar(x_values[0],y1,d_y1,label='Achim 2')
            plt.errorbar(x_values[2],y2,d_y2,label='Achim 3')
            plt.axhline(sr88corr[wash_index], color='r', linestyle='-',label='Achim 1 (i.e. total)')
            plt.xlabel('after [ml] wash')
            plt.ylabel('concentration [ppb]')
            plt.legend()
            plt.title('Column washing')
            plt.savefig('Desktop/Auswertung/column_auswertung_output/wash_corr_'+isotope+'.png',dpi=200)
        
        #Plot as-is-wash concentration
        if 'wash_uncorr' in plots:
            y1=sliceArray(probeconc,wash_slices_1)
            y2=sliceArray(probeconc,wash_slices_2)
            d_y1=sliceArray(d_probeconc,wash_slices_1)
            d_y2=sliceArray(d_probeconc,wash_slices_2)
            plt.figure()
            plt.errorbar(x_values[0],y1,d_y1,label='Achim 2')
            plt.errorbar(x_values[2],y2,d_y2,label='Achim 3')
            plt.axhline(probeconc[wash_index], color='r', linestyle='-',label='Achim 1 (i.e. total)')
            plt.xlabel('after [ml] wash')
            plt.ylabel('concentration [ppb]')
            plt.legend()
            plt.title('Column washing (uncorrected concentration)')
            plt.savefig('Desktop/Auswertung/column_auswertung_output/wash_uncorr_'+isotope+'.png',dpi=200)
        
        #Plot percentage of each wash series' total concentration per step
        if 'wash_perc' in plots:
            y1=sliceArray(probeconc,wash_slices_1)
            y2=sliceArray(probeconc,wash_slices_2)
            d_y1=sliceArray(d_probeconc,wash_slices_1)
            d_y2=sliceArray(d_probeconc,wash_slices_2)
            total1=probeconc[wash_index]
            total2=np.sum(y1)
            total3=np.sum(y2)
            perc1=np.array(probeconc[wash_index])/total1
            perc2=np.array(y1)/total2
            perc3=np.array(y2)/total3
            d_perc1=perc1*np.sqrt((np.sum(d_probeconc[wash_index]**2)/total1**2)+(d_probeconc[wash_index]/probeconc[wash_index])**2)
            d_perc2=perc2*np.sqrt((np.sum(np.array(d_y1)**2)/total2**2)+(np.array(d_y1)/np.array(y1))**2)
            d_perc3=perc3*np.sqrt((np.sum(np.array(d_y2)**2)/total3**2)+(np.array(d_y2)/np.array(y2))**2)
            plt.figure()
            plt.errorbar([x_values[4]],perc1,d_perc1,label='Achim 1')
            plt.errorbar(x_values[0],perc2,d_perc2,label='Achim 2')
            plt.errorbar(x_values[2],perc3,d_perc3,label='Achim 3')
            plt.xlabel('after [ml] elution')
            plt.ylabel('concentration (rel. to total)')
            plt.legend()
            plt.title('Column washing (percentage of uncorr. concentration)')
            plt.savefig('Desktop/Auswertung/column_auswertung_output/wash_perc_'+isotope+'.png',dpi=200)
            
        #Plot percentage of each wash series' total concentration cumulatively
        if 'wash_cumul' in plots:
            y1=sliceArray(probeconc,wash_slices_1)
            y2=sliceArray(probeconc,wash_slices_2)
            d_y1=sliceArray(d_probeconc,wash_slices_1)
            d_y2=sliceArray(d_probeconc,wash_slices_2)
            total1=probeconc[wash_index]
            total2=np.sum(y1)
            total3=np.sum(y2)
            perc1=np.array(probeconc[wash_index])/total1
            perc2=np.array(y1)/total2
            perc3=np.array(y2)/total3
            d_perc1=perc1*np.sqrt((np.sum(d_probeconc[wash_index]**2)/total1**2)+(d_probeconc[wash_index]/probeconc[wash_index])**2)
            d_perc2=perc2*np.sqrt((np.sum(np.array(y1)**2)/total2**2)+(np.array(d_y1)/np.array(y1))**2)
            d_perc3=perc3*np.sqrt((np.sum(np.array(y2)**2)/total3**2)+(np.array(d_y2)/np.array(y2))**2)
            perc1sum=[perc1]
            perc2sum=[perc2[0]]
            perc3sum=[perc3[0]]
            d_perc1sum=[d_perc1]
            d_perc2sum=[d_perc2[0]]
            d_perc3sum=[d_perc3[0]]
            for j in range(1,len(perc2)):
                perc2sum.append(np.sum(perc2[0:j+1]))
                d_perc2sum.append(np.sum(d_perc2[0:j+1]**2))
            for j in range(1,len(perc3)):
                perc3sum.append(np.sum(perc3[0:j+1]))
                d_perc3sum.append(np.sum(d_perc3[0:j+1]**2))
            plt.figure()
            plt.errorbar([x_values[4]],perc1sum,d_perc1sum,label='Achim 1')
            plt.errorbar(x_values[0],perc2sum,d_perc2sum,label='Achim 2')
            plt.errorbar(x_values[2],perc3sum,d_perc3sum,label='Achim 3')
            plt.xlabel('after [ml] elution')
            plt.ylabel('concentration (rel. to total)')
            plt.legend()
            plt.title('Column washing (cumulative percentage of total uncorr. concentration)')
            plt.savefig('Desktop/Auswertung/column_auswertung_output/wash_cumul_'+isotope+'.png',dpi=200)
            
        #Plot raw spectrometer counts for each wash step
        if 'wash_counts' in plots:
            y1=sliceArray(probecounts,wash_slices_1)
            y2=sliceArray(probecounts,wash_slices_2)
            d_y1=sliceArray(d_probecounts,wash_slices_1)
            d_y2=sliceArray(d_probecounts,wash_slices_2)
            plt.figure()
            plt.errorbar(x_values[0],y1,d_y1,label='Achim 2')
            plt.errorbar(x_values[2],y2,d_y2,label='Achim 3')
            plt.axhline(probecounts[wash_index], color='r', linestyle='-',label='Achim 1 (i.e. total)')
            plt.xlabel('after [ml] wash')
            plt.ylabel('counts [a.u.]')
            plt.legend()
            plt.title('Column washing (counts)')
            plt.savefig('Desktop/Auswertung/column_auswertung_output/wash_counts_'+isotope+'.png',dpi=200)
            
        #Plot dilution-corrected elution concentration
        if 'elution_corr' in plots and dilution_factors!=[]:
            y1=sliceArray(sr88corr,elution_slices_1)
            y2=sliceArray(sr88corr,elution_slices_2)
            d_y1=sliceArray(d_sr88corr,elution_slices_1)
            d_y2=sliceArray(d_sr88corr,elution_slices_2)
            plt.figure()
            plt.errorbar(x_values[1],y1,d_y1,label='Achim 2')
            plt.errorbar(x_values[3],y2,d_y2,label='Achim 3')
            plt.axhline(sr88corr[elution_index], color='r', linestyle='-',label='Achim 1 (i.e. total)')
            plt.xlabel('after [ml] elution')
            plt.ylabel('concentration [ppb]')
            plt.legend()
            plt.title('Column elution')   
            plt.savefig('Desktop/Auswertung/column_auswertung_output/elution_corr_'+isotope+'.png',dpi=200)
           
        #Plot as-is-elution concentration
        if 'elution_uncorr' in plots:
            y1=sliceArray(probeconc,elution_slices_1)
            y2=sliceArray(probeconc,elution_slices_2)
            d_y1=sliceArray(d_probeconc,elution_slices_1)
            d_y2=sliceArray(d_probeconc,elution_slices_2)
            plt.figure()
            plt.errorbar(x_values[1],y1,d_y1,label='Achim 2')
            plt.errorbar(x_values[3],y2,d_y2,label='Achim 3')
            plt.axhline(probeconc[elution_index], color='r', linestyle='-',label='Achim 1 (i.e. total)')
            plt.xlabel('after [ml] elution')
            plt.ylabel('concentration [ppb]')
            plt.legend()
            plt.title('Column elution (uncorrected concentration)')
            plt.savefig('Desktop/Auswertung/column_auswertung_output/elution_uncorr_'+isotope+'.png',dpi=200)
            
        #Plot percentage of each elution series' total concentration per step
        if 'elution_perc' in plots:
            y1=sliceArray(probeconc,elution_slices_1)
            y2=sliceArray(probeconc,elution_slices_2)
            d_y1=sliceArray(d_probeconc,elution_slices_1)
            d_y2=sliceArray(d_probeconc,elution_slices_2)
            total1=probeconc[elution_index]
            total2=np.sum(y1)
            total3=np.sum(y2)
            perc1=np.array(probeconc[elution_index])/total1
            perc2=np.array(y1)/total2
            perc3=np.array(y2)/total3
            d_perc1=perc1*np.sqrt((np.sum(d_probeconc[elution_index]**2)/total1**2)+(d_probeconc[elution_index]/probeconc[elution_index])**2)
            d_perc2=perc2*np.sqrt((np.sum(np.array(d_y1)**2)/total2**2)+(np.array(d_y1)/np.array(y1))**2)
            d_perc3=perc3*np.sqrt((np.sum(np.array(d_y2)**2)/total3**2)+(np.array(d_y2)/np.array(y2))**2)
            plt.figure()
            plt.errorbar([x_values[5]],perc1,d_perc1,label='Achim 1')
            plt.errorbar(x_values[1],perc2,d_perc2,label='Achim 2')
            plt.errorbar(x_values[3],perc3,d_perc3,label='Achim 3')
            plt.xlabel('after [ml] elution')
            plt.ylabel('concentration (rel. to total)')
            plt.legend()
            plt.title('Column elution (percentage of uncorr. concentration)')
            plt.savefig('Desktop/Auswertung/column_auswertung_output/elution_perc_'+isotope+'.png',dpi=200)
            
        #Plot percentage of each elution series' total concentration cumulatively
        if 'elution_cumul' in plots:
            y1=sliceArray(probeconc,elution_slices_1)
            y2=sliceArray(probeconc,elution_slices_2)
            d_y1=sliceArray(d_probeconc,elution_slices_1)
            d_y2=sliceArray(d_probeconc,elution_slices_2)
            total1=probeconc[elution_index]
            total2=np.sum(y1)
            total3=np.sum(y2)
            perc1=np.array(probeconc[elution_index])/total1
            perc2=np.array(y1)/total2
            perc3=np.array(y2)/total3
            d_perc1=perc1*np.sqrt((np.sum(d_probeconc[elution_index]**2)/total1**2)+(d_probeconc[elution_index]/probeconc[elution_index])**2)
            d_perc2=perc2*np.sqrt((np.sum(np.array(d_y1)**2)/total2**2)+(np.array(d_y1)/np.array(y1))**2)
            d_perc3=perc3*np.sqrt((np.sum(np.array(d_y2)**2)/total3**2)+(np.array(d_y2)/np.array(y2))**2)
            perc1sum=[perc1]
            perc2sum=[perc2[0]]
            perc3sum=[perc3[0]]
            d_perc1sum=[d_perc1]
            d_perc2sum=[d_perc2[0]]
            d_perc3sum=[d_perc3[0]]
            for j in range(1,len(perc2)):
                perc2sum.append(np.sum(perc2[0:j+1]))
                d_perc2sum.append(np.sum(d_perc2[0:j+1]**2))
            for j in range(1,len(perc3)):
                perc3sum.append(np.sum(perc3[0:j+1]))
                d_perc3sum.append(np.sum(d_perc3[0:j+1]**2))
            plt.figure()
            plt.errorbar([x_values[5]],perc1sum,d_perc1sum,label='Achim 1')
            plt.errorbar(x_values[1],perc2sum,d_perc2sum,label='Achim 2')
            plt.errorbar(x_values[3],perc3sum,d_perc3sum,label='Achim 3')
            plt.xlabel('after [ml] elution')
            plt.ylabel('concentration (rel. to total)')
            plt.legend()
            plt.title('Column elution (cumulative percentage of total uncorr. concentration)')
            #Efficiencies:
            '''
            if original_amount != -1:
                efficiency1=probeconc[elution_index]*sampling
                efficiency2=np.sum(y1)*sampling
                efficiency3=np.sum(y2)*sampling
                d_efficiency1=d_probeconc[elution_index]*sampling
                d_efficiency2=np.sqrt(np.sum(d_y1)**2)*sampling
                d_efficiency3=np.sqrt(np.sum(d_y2)**2)*sampling
                plt.text(1.7,0.5,'Achim 1 total: '+str(round(efficiency1,1))+' $\pm$ '+str(round(d_efficiency1,1))+' pl  -> efficiency: '+str(round(100*efficiency1/original_amount,1))+' %',fontsize='x-small')
                plt.text(1.7,0.45,'Achim 2 total: '+str(round(efficiency2,1))+' $\pm$ '+str(round(d_efficiency2,1))+' pl  -> efficiency: '+str(round(100*efficiency2/original_amount,1))+' %',fontsize='x-small')
                plt.text(1.7,0.4,'Achim 3 total: '+str(round(efficiency3,1))+' $\pm$ '+str(round(d_efficiency3,1))+' pl  -> efficiency: '+str(round(100*efficiency3/original_amount,1))+' %',fontsize='x-small')
            '''
            plt.savefig('Desktop/Auswertung/column_auswertung_output/elution_cumul_'+isotope+'.png',dpi=200)
    
        #Plot raw spectrometer counts for each elution step    
        if 'elution_counts' in plots:
            y1=sliceArray(probecounts,elution_slices_1)
            y2=sliceArray(probecounts,elution_slices_2)
            d_y1=sliceArray(d_probecounts,elution_slices_1)
            d_y2=sliceArray(d_probecounts,elution_slices_2)
            plt.figure()
            plt.errorbar(x_values[1],y1,d_y1,label='Achim 2')
            plt.errorbar(x_values[3],y2,d_y2,label='Achim 3')
            plt.axhline(probecounts[elution_index], color='r', linestyle='-',label='Achim 1 (i.e. total)')
            plt.xlabel('after [ml] elution')
            plt.ylabel('counts [a.u.]')
            plt.legend()
            plt.title('Column elution (counts)')
            plt.savefig('Desktop/Auswertung/column_auswertung_output/elution_counts_'+isotope+'.png',dpi=200)
    
        #Plot custom plot
        symbols=['v','o','<','>','*','s']
        while len(symbols)<len(custom_xs[0]):
            symbols.append(symbols)
        
        if 'custom_counts' in plots:
            for s in range(0,len(custom_slices)):
                plt.figure()
                for j in range(0,len(custom_xs[s])):
                    if len(custom_labels[s])==4:
                        plt.errorbar(custom_xs[s][j],sliceArray(probecounts,custom_slices[s][j]),sliceArray(d_probecounts,custom_slices[s][j]),label=custom_labels[s][3][j],fmt=symbols[j],markersize=9)
                        plt.legend()
                    else:
                        plt.errorbar(custom_xs[s][j],sliceArray(probecounts,custom_slices[s][j]),sliceArray(d_probecounts,custom_slices[s][j]),fmt='.')
                plt.title(custom_labels[s][0]+' (Counts, '+isotope+')')
                plt.xlabel(custom_labels[s][1])
                plt.ylabel('counts in a.u. '+custom_labels[s][2])
                plt.savefig('Desktop/Auswertung/column_auswertung_output/'+custom_labels[s][0]+'_'+isotope+'_counts.png',dpi=200)
                
        if 'custom_conc' in plots:
            for s in range(0,len(custom_slices)):
                plt.figure()
                for j in range(0,len(custom_xs[s])):
                    if len(custom_labels[s])==4:
                        print(custom_xs[s][j])
                        print(sliceArray(probeconc,custom_slices[s][j]))
                        print(sliceArray(d_probeconc,custom_slices[s][j]))
                        print(custom_labels[s][3][j])
                        plt.errorbar(custom_xs[s][j],sliceArray(probeconc,custom_slices[s][j]),sliceArray(d_probeconc,custom_slices[s][j]),label=custom_labels[s][3][j],fmt=symbols[j],markersize=9)
                        plt.legend()
                    else:
                        print(custom_xs[s][j])
                        print(sliceArray(probeconc,custom_slices[s][j]))
                        print(sliceArray(d_probeconc,custom_slices[s][j]))
                        plt.errorbar(custom_xs[s][j],sliceArray(probeconc,custom_slices[s][j]),sliceArray(d_probeconc,custom_slices[s][j]),fmt='.')
                plt.title(custom_labels[s][0]+' (Conc., '+isotope+')')
                plt.xlabel(custom_labels[s][1])
                plt.ylabel('concentration in ppb '+custom_labels[s][2])
                plt.savefig('Desktop/Auswertung/column_auswertung_output/'+custom_labels[s][0]+'_'+isotope+'_concs.png',dpi=200)
                        
        
        
###############################################################################
file='Desktop/Auswertung/Daten/SR-1d_SR-1j_Chemie/20220223_11365_SR1d-SR1j.csv'
blanks=[1,10,18,26,35,44,53,61,69]
drifts=[11,19,27,36,45,54,62,70]
allplots=['calib','calib_counts','drift','wash_corr','wash_uncorr','wash_perc','wash_cumul','wash_counts','elution_corr','elution_uncorr','elution_perc','elution_cumul','elution_counts']
basicplots=['custom_counts','custom_conc']
moreplots=['calib','calib_counts','drift','custom_counts','custom_conc']

#####
#calibconc=[0.8,5,11,50,110,220,500,5000]
calibconc=[5,11,110,220,500,5000]
#calibconcerrors=[0.04,0.25,0.55,2.5,5.5,11,25,250]
calibconcerrors=[0.25,2.5,5.5,11,25,250]
#calibslices=[[2,10]]
calibslices=[[3,4],[5,10]]
washes1=[28,37,46,[55,61]]
elutions1=[[20,26]]
x_values=[[-3,-2,-1,1,2,3,4,5,6],[0.5,1.0,1.5,2.0,2.5,3.0]]

custom_xs=[[[-3,-2,-1,1,2,3,4,5,6]],[[0.5,1.0,1.5,2.0,2.5,3.0]]]
custom_slices=[[[28,37,46,[55,61]]],[[[20,26]]]]
custom_labels=[['Wash von 6.12mg-Probe','ml wash',''],['Elution von 6.12mg-Probe','ml elution','']]
examineSr(filepath=file, isotopes=['Sr88'], recalibrate=True, blank_slices=blanks, calibration_conc=calibconc, d_calibration_conc=calibconcerrors, calibration_slices=calibslices, drift_correction=False, drift_indices=drifts, custom_xs=custom_xs, custom_slices=custom_slices, custom_labels=custom_labels, plots=['custom_conc','calib'], table=True)

custom_xs=[[[1/2*5.67,1/4*5.67,1/8*5.67,1/16*5.67,1/32*5.67,0],[1/2*5.67,1/4*5.67,1/8*5.67,1/16*5.67,1/32*5.67,0],[1/2*5.67,1/4*5.67,1/8*5.67,1/16*5.67,1/32*5.67,0],[1/2*5.67,1/4*5.67,1/8*5.67,1/16*5.67,1/32*5.67,0],[1/2*5.67,1/4*5.67,1/8*5.67,1/16*5.67,1/32*5.67,0]]]
custom_slices=[[[[12,18]],[[29,35]],[[38,44]],[[47,53]],[[63,69]]]]
custom_labels=[['Double elution resolved over steps & mass','Equivalent coral mass [mg]','',['Elution 2', 'Sample 1', 'Wash 1','Sample 2','Wash 2']]]
examineSr(filepath=file, isotopes=['Sr88'], recalibrate=False, blank_slices=blanks, calibration_conc=calibconc, d_calibration_conc=calibconcerrors, calibration_slices=calibslices, drift_correction=False, drift_indices=drifts, custom_xs=custom_xs, custom_slices=custom_slices, custom_labels=custom_labels, plots=['custom_conc'], table=True)

#####
calibconc=[5,50,500,5000]
calibconcerrors=[0.25,2.5,25,250]
calibslices=[3,5,8,9]

custom_xs=[[[-3,-2,-1,1,2,3,4,5,6]],[[0.5,1.0,1.5,2.0,2.5,3.0]]]
custom_slices=[[[28,37,46,[55,61]]],[[[20,26]]]]
custom_labels=[['Wash von 6.12mg-Probe','ml wash',''],['Elution von 6.12mg-Probe','ml elution','']]
examineSr(filepath=file, isotopes=['Rb85'], recalibrate=True, blank_slices=blanks, calibration_conc=calibconc, d_calibration_conc=calibconcerrors, calibration_slices=calibslices, drift_correction=False, drift_indices=drifts, custom_xs=custom_xs, custom_slices=custom_slices, custom_labels=custom_labels, plots=['calib','custom_conc'], table=False)
examineSr(filepath=file, isotopes=['Ca44'], recalibrate=True, blank_slices=blanks, calibration_conc=calibconc, d_calibration_conc=calibconcerrors, calibration_slices=calibslices, drift_correction=False, drift_indices=drifts, custom_xs=custom_xs, custom_slices=custom_slices, custom_labels=custom_labels, plots=['calib','custom_conc'], table=False)

custom_xs=[[[1/2*5.67,1/4*5.67,1/8*5.67,1/16*5.67,1/32*5.67,0],[1/2*5.67,1/4*5.67,1/8*5.67,1/16*5.67,1/32*5.67,0],[1/2*5.67,1/4*5.67,1/8*5.67,1/16*5.67,1/32*5.67,0],[1/2*5.67,1/4*5.67,1/8*5.67,1/16*5.67,1/32*5.67,0],[1/2*5.67,1/4*5.67,1/8*5.67,1/16*5.67,1/32*5.67,0]]]
custom_slices=[[[[12,18]],[[29,35]],[[38,44]],[[47,53]],[[63,69]]]]
custom_labels=[['Double elution resolved over steps & mass','Equivalent coral mass [mg]','',['Elution 2', 'Sample 1', 'Wash 1','Sample 2','Wash 2']]]
examineSr(filepath=file, isotopes=['Rb85'], recalibrate=True, blank_slices=blanks, calibration_conc=calibconc, d_calibration_conc=calibconcerrors, calibration_slices=calibslices, drift_correction=False, drift_indices=drifts, custom_xs=custom_xs, custom_slices=custom_slices, custom_labels=custom_labels, plots=['custom_conc'], table=False)
examineSr(filepath=file, isotopes=['Ca44'], recalibrate=True, blank_slices=blanks, calibration_conc=calibconc, d_calibration_conc=calibconcerrors, calibration_slices=calibslices, drift_correction=False, drift_indices=drifts, custom_xs=custom_xs, custom_slices=custom_slices, custom_labels=custom_labels, plots=['custom_conc'], table=False)

#####
'''
print(np.sqrt(0.825/2.12),np.sqrt(0.326/1.08),np.sqrt(0.0134/0.831),np.sqrt(0.0081/0.265),np.sqrt(0.0067/0.133))
print(np.sqrt(2646/11497),np.sqrt(2847/5861))
'''